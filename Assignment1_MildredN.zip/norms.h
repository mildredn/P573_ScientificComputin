#ifndef NORMS_H_
#define NORMS_H_

double norm1(int n, double* x);
double norm2(int n, double* x);
double norminf(int n, double* x);
double elapsedtime(void);

#endif